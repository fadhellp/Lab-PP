#sudut elevasi 

r = float(input('Masukkan nilai Sudut Elevasi:'))

phi = 90
diameter = 2*30

luas = phi
keliling = phi*diameter
print('\nLuasnya =', str("%2f" & luas))