print("Tagihan Listrik")
def total(harga,jumlah):
    """fungsi untuk menghitung total bayar"""
    return harga 
#Input data
b2= int(input("1.444,70"))
p1= int(input("1.523,28"))

#Menghitung total tagihan
a= int(input("Golongan b2= "))
b= int(input("Golongan p1= "))

tagihan ("a+b =")
